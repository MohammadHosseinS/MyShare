global using Ardalis.GuardClauses;
global using CleanArchitecture.Web.Infrastructure;
global using MediatR;
