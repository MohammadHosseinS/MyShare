﻿namespace CleanArchitecture.Application.TodoLists.Queries.GetTodos;

public class PriorityLevelDto
{
    public int Value { get; init; }

    public string? Name { get; init; }
}
